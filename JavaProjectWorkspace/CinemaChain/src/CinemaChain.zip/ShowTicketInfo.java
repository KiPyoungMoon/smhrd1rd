package CinemaChain;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SpringLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;



public class ShowTicketInfo extends JFrame{

	private JFrame frame;
	private ImageIcon icon;
	private JScrollPane scrollPane;
//	private MovieDAO dbms = new MovieDAO();
//	private ArrayList<TicketDTO> ticketList = dbms.getTicket(email); //Ƽ�� Ȯ�� ��ư ������ �� �ε����� Ƽ�ϵ�Ƽ�� ����;��ҵ�
	
	//�׽�Ʈ������ ���� ��ü. ���߿� ��������
	private TicketDTO ticketList = new TicketDTO("qnemaqnema@naver.com", "�ȳ��̶� �߱��� ��ȭ","2018-01-27", "�ȳ��� ��ȭ��", "����Ʈ �ȳ��̰�", "12:00", "12 13 14 ", 30000);
	
	
	/**
	 * Launch the application.
	 */
	static int width = 336;
	static int height = 600;
	public static void main(String[] args) {
		ShowTicketInfo frame = new ShowTicketInfo();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(width+17, height+37);
		frame.setVisible(true);
	}

	/**
	 * Create the application.
	 */
	public ShowTicketInfo() {
		
		icon = fileImgResize(width, height, "../CinemaChain/src/CinemaChain/ticketBackground.png");

		// ��� Panel ������ �������������� ����
		JPanel background = new JPanel() {
			public void paintComponent(Graphics g) {
				// Approach 1: Dispaly image at at full size
				g.drawImage(icon.getImage(), 0, 0, null);
				// Approach 2: Scale image to size of component
				// Dimension d = getSize();
				// g.drawImage(icon.getImage(), 0, 0, d.width, d.height, null);
				// Approach 3: Fix the image position in the scroll pane
				// Point p = scrollPane.getViewport().getViewPosition();
				// g.drawImage(icon.getImage(), p.x, p.y, null);
				setOpaque(false); // �׸��� ǥ���ϰ� ����,�����ϰ� ����
				super.paintComponent(g);
			}
		};

		scrollPane = new JScrollPane(background);
		setContentPane(scrollPane);
		SpringLayout springLayout = new SpringLayout();
		background.setLayout(springLayout);
		
		int west = 109; // ������ �ʹ� �� ��� �߶��ֱ� ���� width���� west,east����
		int east = 330;
		
		JLabel titleLb = new JLabel();
		springLayout.putConstraint(SpringLayout.NORTH, titleLb, 197, SpringLayout.NORTH, background);
		springLayout.putConstraint(SpringLayout.WEST, titleLb, 109, SpringLayout.WEST, background);
		springLayout.putConstraint(SpringLayout.SOUTH, titleLb, 238, SpringLayout.NORTH, background);
		springLayout.putConstraint(SpringLayout.EAST, titleLb, 330, SpringLayout.WEST, background);
		titleLb.setVerticalAlignment(SwingConstants.TOP);
		titleLb.setFont(new Font("HYGothic �߰�", Font.BOLD, 15));
//		titleLb.setForeground(Color.WHITE);
		titleLb.setText(textAlign(east-west, ticketList.getTitle()));
		background.add(titleLb);
		
		JLabel dateLb = new JLabel("New label");
		springLayout.putConstraint(SpringLayout.NORTH, dateLb, 242, SpringLayout.NORTH, background);
		springLayout.putConstraint(SpringLayout.WEST, dateLb, 0, SpringLayout.WEST, titleLb);
		springLayout.putConstraint(SpringLayout.EAST, dateLb, 0, SpringLayout.EAST, titleLb);
		dateLb.setFont(new Font("HYGothic �߰�", Font.BOLD, 15));
//		dateLb.setForeground(Color.WHITE);
		dateLb.setText(textAlign(east-west, ticketList.getCinemaTime()));
		background.add(dateLb);
		
		int threeWest = 130; //3���ڰ� �ִ� ���� �� ��ġ���� �����Ұ���
		
		JLabel lblNewLabel = new JLabel("New label");
		springLayout.putConstraint(SpringLayout.NORTH, lblNewLabel, 287, SpringLayout.NORTH, background);
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		springLayout.putConstraint(SpringLayout.WEST, lblNewLabel, 130, SpringLayout.WEST, background);
		springLayout.putConstraint(SpringLayout.SOUTH, lblNewLabel, 310, SpringLayout.NORTH, background);
		springLayout.putConstraint(SpringLayout.EAST, lblNewLabel, 0, SpringLayout.EAST, titleLb);
		background.add(lblNewLabel);
		
		
	}

	public String textAlign(int width,String string) { //�ʺ�� ��Ʈ��
	      
	      return String.format("<html><div WIDTH=%d>%s</div><html>",width /*�ʺ�*/,string/*��Ʈ������*/);
	   }
	public static ImageIcon fileImgResize(int width, int height, String url) { // guiȭ�鿡�� main�� �ƹ����� �־��ָ� �˴ϴ�. �̹��� �ּ� �ʿ��ؿ�!
		ImageIcon poster = null;
		try {
			File imgUrl = new File(url);
			poster = new ImageIcon(ImageIO.read(imgUrl).getScaledInstance(width, height, java.awt.Image.SCALE_SMOOTH));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return poster;
	}
}
