package CinemaChain;

import java.awt.Choice;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SpringLayout;

public class TimeInfo extends JFrame {

	private ImageIcon icon;
	private JScrollPane scrollPane;
	private Choice theaterChoice;

	public TimeInfo() {

		icon = new ImageIcon("../CinemaChain/src/CinemaChain/ticketing.png");

		// ��� Panel ������ �������������� ����
		JPanel background = new JPanel() {
			public void paintComponent(Graphics g) {
				// Approach 1: Dispaly image at at full size
				g.drawImage(icon.getImage(), 0, 0, null);
				// Approach 2: Scale image to size of component
				// Dimension d = getSize();
				// g.drawImage(icon.getImage(), 0, 0, d.width, d.height, null);
				// Approach 3: Fix the image position in the scroll pane
				// Point p = scrollPane.getViewport().getViewPosition();
				// g.drawImage(icon.getImage(), p.x, p.y, null);
				setOpaque(false); // �׸��� ǥ���ϰ� ����,�����ϰ� ����
				super.paintComponent(g);
			}
		};
		SpringLayout sl_background = new SpringLayout();
		background.setLayout(sl_background);

		scrollPane = new JScrollPane(background);

		theaterChoice = new Choice();
		sl_background.putConstraint(SpringLayout.NORTH, theaterChoice, 162, SpringLayout.NORTH, background);
		sl_background.putConstraint(SpringLayout.SOUTH, theaterChoice, -417, SpringLayout.SOUTH, background);
		sl_background.putConstraint(SpringLayout.EAST, theaterChoice, -105, SpringLayout.EAST, background);
		background.add(theaterChoice);

		String posterUrl = CinemaChainHome.movieInfoListCenter.get(0).getPosterSrc();
		JButton poster = new JButton(CinemaChainHome.imgResize(360, 480, posterUrl));
		sl_background.putConstraint(SpringLayout.WEST, theaterChoice, 91, SpringLayout.EAST, poster);
		sl_background.putConstraint(SpringLayout.NORTH, poster, 134, SpringLayout.NORTH, background);
		sl_background.putConstraint(SpringLayout.WEST, poster, 38, SpringLayout.WEST, background);
		sl_background.putConstraint(SpringLayout.SOUTH, poster, -154, SpringLayout.SOUTH, background);
		sl_background.putConstraint(SpringLayout.EAST, poster, 399, SpringLayout.WEST, background);
		background.add(poster);
		poster.setBorder(null);
		poster.setFocusable(false);
		poster.setFocusPainted(false);

		Choice screenChoice = new Choice();
		sl_background.putConstraint(SpringLayout.NORTH, screenChoice, 17, SpringLayout.SOUTH, theaterChoice);
		sl_background.putConstraint(SpringLayout.WEST, screenChoice, 0, SpringLayout.WEST, theaterChoice);
		sl_background.putConstraint(SpringLayout.SOUTH, screenChoice, 26, SpringLayout.SOUTH, theaterChoice);
		sl_background.putConstraint(SpringLayout.EAST, screenChoice, 0, SpringLayout.EAST, theaterChoice);
		background.add(screenChoice);

		Choice showTimeChoice = new Choice();
		sl_background.putConstraint(SpringLayout.NORTH, showTimeChoice, 105, SpringLayout.SOUTH, screenChoice);
		sl_background.putConstraint(SpringLayout.WEST, showTimeChoice, 0, SpringLayout.WEST, theaterChoice);
		sl_background.putConstraint(SpringLayout.SOUTH, showTimeChoice, -217, SpringLayout.SOUTH, background);
		sl_background.putConstraint(SpringLayout.EAST, showTimeChoice, 0, SpringLayout.EAST, theaterChoice);
		background.add(showTimeChoice);

		JButton getSeat = new JButton();
		sl_background.putConstraint(SpringLayout.NORTH, getSeat, -124, SpringLayout.SOUTH, background);
		sl_background.putConstraint(SpringLayout.WEST, getSeat, -18, SpringLayout.WEST, theaterChoice);
		sl_background.putConstraint(SpringLayout.SOUTH, getSeat, -59, SpringLayout.SOUTH, background);
		sl_background.putConstraint(SpringLayout.EAST, getSeat, 0, SpringLayout.EAST, theaterChoice);
		getSeat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (!showTimeChoice.getSelectedItem().equals("����")) {
					// �¼� ���� ȭ�鿡 �Ѱ��� ��ȭ��, �󿵰�, �󿵽ð�.
					Seat.main(null, theaterChoice.getSelectedItem(), screenChoice.getSelectedItem(),
							showTimeChoice.getSelectedItem());
				}
			}
		});
		background.add(getSeat);
		setContentPane(scrollPane);
		getSeat.setContentAreaFilled(false);
		getSeat.setBorder(null);
		getSeat.setOpaque(false);

		for (int i = 0; i < CinemaChainHome.movieInfoListCenter.size(); i++) {
			String theater = CinemaChainHome.movieInfoListCenter.get(i).getTheater();
			// ��ȭ Ÿ��Ʋ�� �´� ��ȭ�� ��� �Ѹ���
			if (i == 0) {
				theaterChoice.add(theater);
			} else if (!theater.equals(CinemaChainHome.movieInfoListCenter.get(i - 1).getTheater())) {
				theaterChoice.add(theater);
			}
		}

		screenChoice.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ��ũ�� ���̽��� ���� ���� ��, �ش� ��ȭ���� ��ũ�� ������ ��ũ�� ���̽��� �Ѹ���.

			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				screenChoice.removeAll();
				for (int i = 0; i < CinemaChainHome.movieInfoListCenter.size(); i++) {
					if (theaterChoice.getSelectedItem()
							.equals(CinemaChainHome.movieInfoListCenter.get(i).getTheater())) {
						if (screenChoice.getItemCount() == 0)
							screenChoice.add(CinemaChainHome.movieInfoListCenter.get(i).getScreen());
						else if (!CinemaChainHome.movieInfoListCenter.get(i).getScreen()
								.equals(CinemaChainHome.movieInfoListCenter.get(i - 1).getScreen())) {
							screenChoice.add(CinemaChainHome.movieInfoListCenter.get(i).getScreen());
						}
					}
				}
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void mouseReleased(MouseEvent arg0) {

			}

		});

		showTimeChoice.addMouseListener(new MouseListener() {
			@Override
			public void mouseReleased(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				showTimeChoice.removeAll();
				for (int i = 0; i < CinemaChainHome.movieInfoListCenter.size(); i++) {
					if (screenChoice.getSelectedItem().equals(CinemaChainHome.movieInfoListCenter.get(i).getScreen())) {
						showTimeChoice.add(CinemaChainHome.movieInfoListCenter.get(i).getTime());
					}
				}
			}
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
	}

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		TimeInfo frame = new TimeInfo();
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setSize(880, 800);
		frame.setVisible(true);
	}
}
